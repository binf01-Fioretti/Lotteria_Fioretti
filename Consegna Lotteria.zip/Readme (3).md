PROGETTO LOTTERIA:
Scopo: lo scopo di questo progetto è creare un codice per far in modo che venga simulata una vera e propria lotteria
in base alla quale l'utente sceglie un numero, successivamente viene fatta una estrazione e si verifica se
l'utente ha vinto
Principali classi Usate:
-Lotteria: c'è il metodo main
-Giocatore: viene definito l'oggetto giocatore e un numero che sceglie lui
-Estrazione: viene effettuata l'estrazione vera e propria
Librerie Usate:
-random
-la libreria per il catch
-BufferedReader